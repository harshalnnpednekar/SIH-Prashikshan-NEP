import React from 'react';
import { Link } from 'react-router-dom';
export default function Navbar(){
  return (
    <nav className="navbar">
      <div className="nav-left">
        <Link to="/" className="logo">Prashikshan</Link>
      </div>
      <div className="nav-right">
        <Link to="/roles">Register</Link>
        <Link to="/student">Student</Link>
        <Link to="/college">College</Link>
        <Link to="/industry">Industry</Link>
      </div>
    </nav>
  );
}
