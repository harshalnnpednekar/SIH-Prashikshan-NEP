import React from 'react';
export default function Footer(){
  return (
    <footer className="footer">
      <p>© 2025 Prashikshan — NEP Aligned Internship Platform</p>
    </footer>
  );
}
