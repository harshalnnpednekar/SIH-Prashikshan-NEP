import React from 'react';
import { Link } from 'react-router-dom';
export default function LandingPage(){
  return (
    <div className="main-hero">
      <div className="container">
        <h1 style={{color:'var(--blue)'}}>Prashikshan</h1>
        <p style={{maxWidth:700,margin:'12px auto'}}>Bridging Students, Colleges & Industries for NEP Internships — discover, apply, track & get certified.</p>
        <div style={{marginTop:20}}>
          <Link className="btn btn-primary" to="/roles">Register</Link>
          <Link className="btn btn-secondary" to="/roles" style={{marginLeft:12}}>Select Role</Link>
        </div>

        <div className="grid" style={{marginTop:32}}>
          <div className="card">
            <h3>Discover</h3>
            <small>Search verified internships</small>
          </div>
          <div className="card">
            <h3>Apply</h3>
            <small>Apply and track your applications</small>
          </div>
          <div className="card">
            <h3>Get Certified</h3>
            <small>Auto-generated NEP-compliant certificates</small>
          </div>
        </div>
      </div>
    </div>
  );
}
