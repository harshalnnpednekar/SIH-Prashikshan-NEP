import React from 'react';
export default function LogbookPage(){
  return (
    <div className="container">
      <h2>Logbook</h2>
      <div className="card">
        <h4>Week 1</h4>
        <p>Orientation & setup</p>
      </div>
      <div className="card">
        <h4>Week 2</h4>
        <p>Requirement analysis</p>
      </div>
    </div>
  );
}
