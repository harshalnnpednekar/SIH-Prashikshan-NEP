import React from 'react';
export default function CollegeDashboard(){
  const students = [
    {id:1,name:'Harshal Patil',internship:'Web Dev',progress:80},
    {id:2,name:'Anita Sharma',internship:'Data Analytics',progress:60}
  ];
  return (
    <div className="container">
      <h2>College Dashboard</h2>
      <div className="grid">
        <div className="card">
          <h4>Students & Progress</h4>
          {students.map(s=>(
            <div key={s.id} style={{marginTop:8}}>
              <strong>{s.name}</strong>
              <div><small>{s.internship} • {s.progress}%</small></div>
              <div style={{marginTop:6}}><button className="btn btn-primary">Issue Certificate</button></div>
            </div>
          ))}
        </div>
        <div className="card">
          <h4>Mentor Assignment</h4>
          <small>Assign mentors to students and track</small>
        </div>
      </div>
    </div>
  );
}
