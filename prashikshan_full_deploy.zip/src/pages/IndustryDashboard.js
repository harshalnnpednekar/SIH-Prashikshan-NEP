import React from 'react';
export default function IndustryDashboard(){
  const posts = [
    {id:1,title:'Web Dev Internship',applicants:12,onboarded:3},
    {id:2,title:'Data Analytics Internship',applicants:5,onboarded:1}
  ];
  return (
    <div className="container">
      <h2>Industry Dashboard</h2>
      <div className="grid">
        <div className="card">
          <h4>Postings</h4>
          {posts.map(p=>(
            <div key={p.id} style={{marginTop:8}}>
              <strong>{p.title}</strong>
              <div><small>Applicants: {p.applicants} • Onboarded: {p.onboarded}</small></div>
              <div style={{marginTop:6}}><button className="btn btn-primary">Onboard +1</button></div>
            </div>
          ))}
        </div>
        <div className="card">
          <h4>Manage Applicants</h4>
          <small>Review and offer internships</small>
        </div>
      </div>
    </div>
  );
}
