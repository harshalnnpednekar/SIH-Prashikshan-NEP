import React from 'react';
import { Link } from 'react-router-dom';
export default function StudentDashboard(){
  const internships = [
    {id:1,title:'Web Development Intern',company:'TechCorp',location:'Remote',duration:'3 months'},
    {id:2,title:'Data Analytics Intern',company:'DataWorks',location:'Mumbai',duration:'2 months'}
  ];
  const trainings = [
    {id:1,title:'Resume Building',progress:80},
    {id:2,title:'Communication Skills',progress:45}
  ];
  return (
    <div className="container">
      <h2>Student Dashboard</h2>
      <div className="grid">
        <div className="card">
          <h4>Available Internships</h4>
          {internships.map(i=>(
            <div key={i.id} style={{marginTop:8}}>
              <strong>{i.title}</strong>
              <div><small>{i.company} • {i.location}</small></div>
              <div style={{marginTop:6}}><button className="btn btn-primary">Apply</button></div>
            </div>
          ))}
        </div>
        <div className="card">
          <h4>Pre-Internship Training</h4>
          {trainings.map(t=>(
            <div key={t.id} style={{marginTop:8}}>
              <strong>{t.title}</strong>
              <div style={{marginTop:6}}><small>{t.progress}% complete</small></div>
            </div>
          ))}
        </div>
        <div className="card">
          <h4>Logbook Tracker</h4>
          <small>Weekly entries & progress</small>
          <div style={{marginTop:8}}><Link to="/logbook" className="btn btn-primary">Open Logbook</Link></div>
        </div>
      </div>
    </div>
  );
}
