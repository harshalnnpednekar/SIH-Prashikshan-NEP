import React from 'react';
import { Link } from 'react-router-dom';
export default function RoleSelect(){
  return (
    <div className="container" style={{textAlign:'center',paddingTop:30}}>
      <h2>Select Role</h2>
      <div className="role-cards">
        <Link className="role-card" to="/student"><h3 style={{color:'var(--blue)'}}>Student</h3><p>Find & track internships</p></Link>
        <Link className="role-card" to="/college"><h3 style={{color:'var(--teal)'}}>College</h3><p>Mentor & approve credits</p></Link>
        <Link className="role-card" to="/industry"><h3 style={{color:'var(--green)'}}>Industry</h3><p>Post internships & onboard</p></Link>
      </div>
    </div>
  );
}
