import React from 'react';
export default function CertificatePage(){
  return (
    <div className="container">
      <h2>Certificate Preview</h2>
      <div className="card">
        <h3>Certificate of Internship</h3>
        <p>This is a sample auto-generated certificate preview.</p>
      </div>
    </div>
  );
}
