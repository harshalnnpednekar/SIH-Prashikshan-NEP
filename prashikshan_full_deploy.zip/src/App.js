import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

import LandingPage from './pages/LandingPage';
import RoleSelect from './pages/RoleSelect';
import StudentDashboard from './pages/StudentDashboard';
import CollegeDashboard from './pages/CollegeDashboard';
import IndustryDashboard from './pages/IndustryDashboard';
import LogbookPage from './pages/LogbookPage';
import CertificatePage from './pages/CertificatePage';

function App() {
  return (
    <>
      <Navbar />
      <main style={{minHeight: '70vh'}}>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/roles" element={<RoleSelect />} />
          <Route path="/student" element={<StudentDashboard />} />
          <Route path="/college" element={<CollegeDashboard />} />
          <Route path="/industry" element={<IndustryDashboard />} />
          <Route path="/logbook" element={<LogbookPage />} />
          <Route path="/certificate" element={<CertificatePage />} />
        </Routes>
      </main>
      <Footer />
    </>
  );
}

export default App;
