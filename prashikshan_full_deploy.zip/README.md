
# Prashikshan Frontend (Prototype)

This is a minimal React (Create React App) frontend prototype for the "Prashikshan" internship platform.
It includes:
- Landing page with Register and Role selection
- Student / College / Industry dashboards (dummy content)
- Logbook page, Certificate preview
- Vercel config for simple deploy

## Run locally (if you have Node.js)
1. unzip prashikshan_full_deploy.zip
2. cd prashikshan_full_deploy
3. npm install
4. npm start
Open http://localhost:3000

## Deploy on Vercel
Option A (recommended - via GitHub)
1. Create a repo on GitHub and push this folder.
2. On Vercel dashboard, import the GitHub repository and deploy (Vercel auto-detects React).

Option B (direct upload)
1. In Vercel dashboard, click "New Project" -> "Import Project" -> scroll down to find "Deploy from a local directory" or "Upload".
2. Upload the folder contents (ensure package.json is in the root).
3. Set Build Command: `npm run build` and Output Directory: `build` (Vercel usually sets this automatically).

Notes:
- This is a frontend-only prototype with dummy static content. To persist data, connect to a backend API.
- If you see a 404 after deploy, ensure the root of uploaded ZIP contains package.json, src and public folders (not nested inside another folder).
